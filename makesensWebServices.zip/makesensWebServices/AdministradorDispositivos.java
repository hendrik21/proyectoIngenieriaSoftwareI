/**
 * @Class AdministradorDispositivos
 * @author Hendrik Lopez 
 * @version 07/08/2022
 */
public class AdministradorDispositivos
{
    // instance variables - replace the example below with your own
    public String Id;
    private String Nombre;
    private String Correo;
    private String Telefono;
    private String Contraseña;
    private Dispositivo[] DispositivosEnlazados;
    

    /**
     * Constructor for objects of class AdministradorDispositivos
     */
    public AdministradorDispositivos(String Id, String Nombre, String Correo, String Telefono, String Contraseña, Dispositivo[] DispositivosEnlazados)
    {
        this.Id = Id;
        this.Nombre = Nombre;
        this.Correo = Correo;
        this.Telefono = Telefono;
        this.Contraseña = Contraseña;
        this.DispositivosEnlazados = DispositivosEnlazados;
    }

    /**
     * METHODS
     */
    public void iniciarSesion(String Correo, String Contraseña)
    {
        
    }
    
    public void cerrarSesion()
    {
        
    }
    
    public void modificarContraseña(String Correo, String Contraseña) 
    {
    
    }
    
    public void registrarUsuario(String Nombre, String Correo, String Telefono)
    {
    
    }
}
