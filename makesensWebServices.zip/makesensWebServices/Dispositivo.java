/**
 * @Class Dispositivo
 * @author Hendrik Lopez 
 * @version 07/08/2022
 */

import java.util.ArrayList;

public class Dispositivo
{
    // instance variables - replace the example below with your own
    public String Id;
    protected String IdUsuario;
    protected String Nombre;
    protected String Descripcion;
    protected String Tipo;
    protected int Latitud;
    protected int Longitud;
    protected int FechaUltimaConexion;
    protected int FechaUltimaActualizacion;
    protected boolean EstadoConexion;
    protected String EstadoActualizacion;
    protected String VersionFirmware;
    protected String CorreoNotificaciones;
    protected String Foto;
    ArrayList<Dispositivo> listaDispositivos = new ArrayList<Dispositivo>();

    /**
     * Constructor for objects of class Dispositivo
     */
    public Dispositivo(String Id, String IdUsuario, String Nombre, String Descripcion,String Tipo, int Latitud, int Longitud, int FechaUltimaConexion, int FechaUltimaActualizacion, boolean EstadoConexion, String EstadoActualizacion, String VersionFirmware, String CorreoNotificaciones, String Foto)
    {
        this.Id = Id;
        this.IdUsuario = IdUsuario;
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
        this.Tipo = Tipo;
        this.Latitud = Latitud;
        this.Longitud = Longitud;
        this.FechaUltimaConexion = FechaUltimaConexion;
        this.FechaUltimaActualizacion = FechaUltimaActualizacion;
        this.EstadoConexion = EstadoConexion;
        this.EstadoActualizacion = EstadoActualizacion;
        this.VersionFirmware = VersionFirmware;
        this.CorreoNotificaciones = CorreoNotificaciones;
        this.Foto = Foto;
    
    }

    
    public ArrayList<Dispositivo> obtenerPorUsuario(String IdUsuario)
    {
        ArrayList<Dispositivo> dispositivosFiltrado = new ArrayList<Dispositivo>();
        for (int i = 0; i <= listaDispositivos.size(); i++) 
        {
            if (listaDispositivos.get(i).IdUsuario == IdUsuario)
            {
                dispositivosFiltrado.add(listaDispositivos.get(i));
            }
        }
        return dispositivosFiltrado;
    }
    
    public ArrayList<Dispositivo> obtenerPorId(String IdDispositivo)
    {
        ArrayList<Dispositivo> dispositivosFiltrado = new ArrayList<Dispositivo>();
        for (int i = 0; i <= listaDispositivos.size(); i++) 
        {
            if (listaDispositivos.get(i).Id == Id)
            {
                dispositivosFiltrado.add(listaDispositivos.get(i));
            }
        }
        return dispositivosFiltrado;    
    
    }
    
    public ArrayList<Dispositivo> obtenerPorFirmware(String Firmware)
    {
        ArrayList<Dispositivo> dispositivosFiltrado = new ArrayList<Dispositivo>();
        for (int i = 0; i <= listaDispositivos.size(); i++) 
        {
            if (listaDispositivos.get(i).VersionFirmware == Firmware)
            {
                dispositivosFiltrado.add(listaDispositivos.get(i));
            }
        }
        return dispositivosFiltrado;
    }
    
    public ArrayList<Dispositivo> obtenerPorEstadoConexion(boolean EstadoConexion)
    {
        ArrayList<Dispositivo> dispositivosFiltrado = new ArrayList<Dispositivo>();
        for (int i = 0; i <= listaDispositivos.size(); i++) 
        {
            if (listaDispositivos.get(i).EstadoConexion == EstadoConexion)
            {
                dispositivosFiltrado.add(listaDispositivos.get(i));
            }
        }
        return dispositivosFiltrado;
    }
    
    public ArrayList<Dispositivo> obtenerPorEstadoActualizacion(String EstadoActualizacion)
    {
        ArrayList<Dispositivo> dispositivosFiltrado = new ArrayList<Dispositivo>();
        for (int i = 0; i <= listaDispositivos.size(); i++) 
        {
            if (listaDispositivos.get(i).EstadoActualizacion == EstadoActualizacion)
            {
                dispositivosFiltrado.add(listaDispositivos.get(i));
            }
        }
        return dispositivosFiltrado;
    }
    
    
    public Dispositivo editarDispositivo(String IdDispositivo)
    {
        Dispositivo Dispositivo = new Dispositivo(Id, IdUsuario, Nombre, Descripcion,Tipo, Latitud, Longitud, FechaUltimaConexion, FechaUltimaActualizacion, EstadoConexion, EstadoActualizacion, VersionFirmware, CorreoNotificaciones, Foto);
        return Dispositivo;
    }
    
    public Dispositivo enlazarDispositivo(String IdUsuario)
    {
        Dispositivo Dispositivo = new Dispositivo(Id, IdUsuario, Nombre, Descripcion,Tipo, Latitud, Longitud, FechaUltimaConexion, FechaUltimaActualizacion, EstadoConexion, EstadoActualizacion, VersionFirmware, CorreoNotificaciones, Foto);
        return Dispositivo;
    }
}
