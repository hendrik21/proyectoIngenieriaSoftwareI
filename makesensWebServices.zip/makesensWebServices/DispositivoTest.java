

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class DispositivoTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class DispositivoTest
{
    /**
     * Default constructor for test class DispositivoTest
     */
    public DispositivoTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }

    @Test
    public void prueba()
    {
        Dispositivo disposit1 = new Dispositivo("1", "1", "1", "1", "EVA", 34, 23, 56456, 56456, true, "Actualizado", "1", "rhnthgrybtyhj", "rhnthgrybtyhj");
    }
}

