
/**
 * @Class EstadoActualizacion
 * @author Hendrik Lopez 
 * @version 07/08/2022
 */
import java.util.ArrayList;
public class EstadoActualizacion
{
    // instance variables - replace the example below with your own
    protected String Id;
    protected String IdDispositivo;
    protected int FechaCambioEstado;
    protected String Estado;
    ArrayList<EstadoActualizacion> listaEstadosActualizacion = new ArrayList<EstadoActualizacion>();

    /**
     * Constructor for objects of class EstadoActualizacion
     */
    public EstadoActualizacion(String Id, String IdDispositivo, int FechaCambioEstado, String Estado)
    {
        this.Id = Id;
        this.IdDispositivo = IdDispositivo;
        this.FechaCambioEstado = FechaCambioEstado;
        this.Estado = Estado;
    }

    /**
     * METHODS 
     */
    public ArrayList<EstadoActualizacion> obtenerEstados(String IdDispositivo)
    {
        ArrayList<EstadoActualizacion> EstadosActualizacionFiltrado = new ArrayList<EstadoActualizacion>();
        for (int i = 0; i <= listaEstadosActualizacion.size(); i++) 
        {
            if (listaEstadosActualizacion.get(i).IdDispositivo == IdDispositivo)
            {
                EstadosActualizacionFiltrado.add(listaEstadosActualizacion.get(i));
            } else 
            {
                System.out.println("NO HAY ESTADOS");
            }
        }
        return EstadosActualizacionFiltrado;
    }
}
