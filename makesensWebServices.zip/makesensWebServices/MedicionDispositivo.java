
/**
 * @Class MedicionDispositivo
 * @author Hendrik Lopez 
 * @version 07/08/2022
 */
public class MedicionDispositivo
{
    
    public String Id;
    protected int FechaMedicion;
    protected int DatoMedicion;

    /**
     * Constructor for objects of class MedicionDispositivo
     */
    public MedicionDispositivo(String Id, int FechaMedicion, int DatoMedicion)
    {
        this.Id = Id;
        this.FechaMedicion = FechaMedicion;
        this.DatoMedicion = DatoMedicion;
    }

    public MedicionDispositivo subirMedicion() 
    {
        MedicionDispositivo medicion = new MedicionDispositivo(Id, FechaMedicion, DatoMedicion);
        return medicion;
    }
}
