
/**
 * @Class MedicionPluviometro
 * @author Hendrik Lopez 
 * @version 07/08/2022
 */
import java.util.ArrayList;
public class MedicionPluviometro
{
    private String Id;
    protected String IdUsuario;
    private String Nombre;
    private int FechaMedicion;
    private int DatoMedicion;
    private String Ubicacion;
    private String FotoPluviometro;
    ArrayList<MedicionPluviometro> listaMedicionesPluviometro = new ArrayList<MedicionPluviometro>();
    /**
     * Constructor for objects of class MedicionPluviometro
     */
    public MedicionPluviometro(String Id, String IdUsuario,String Nombre, int FechaMedicion, int DatoMedicion, String Ubicacion, String FotoPluviometro)
    {
        this.Id = Id;
        this.IdUsuario = IdUsuario;
        this.Nombre = Nombre;
        this.FechaMedicion = FechaMedicion;
        this.DatoMedicion = DatoMedicion;
        this.Ubicacion = Ubicacion;
        this.FotoPluviometro = FotoPluviometro;
    }

    /**
     * METHODS
     */
    public ArrayList<MedicionPluviometro> obtenerMediciones(String IdUsuario)
    {
        ArrayList<MedicionPluviometro> MedicionesPluviometroFiltrado = new ArrayList<MedicionPluviometro>();
        for (int i = 0; i <= listaMedicionesPluviometro.size(); i++) 
        {
            if (listaMedicionesPluviometro.get(i).IdUsuario == IdUsuario)
            {
                MedicionesPluviometroFiltrado.add(listaMedicionesPluviometro.get(i));
            }
        }
        return MedicionesPluviometroFiltrado;
    }
    
    public MedicionPluviometro subirMedicion(String Nombre, int DatoMedicion, String Ubicacion, String FotoPluviometro)
    {
        MedicionPluviometro medicion = new MedicionPluviometro(Id, IdUsuario, Nombre, FechaMedicion, DatoMedicion, Ubicacion, FotoPluviometro);
        
        return medicion;
    }
}
